bl_info = {
    "name": "DV Skin Tools",
    "author": "Davood Taba <davoodice@gmail.com>",
    "version": (0, 8, 31),
    "blender": (4, 2, 0),
    "location": "3D Viewport > Weight Paint > Sidebar > DV Skin Tools",
    "description": "Maya-style multi-influence skinning: smooth, bind nearest, replace/add/remove",
    "category": "Paint",
    "doc_url": "",
}

import hashlib
import importlib.abc
import importlib.machinery
import os
import pickle
import sys
import zlib

import bpy
from bpy.app.handlers import persistent

_PKG = __name__
_DIR = os.path.dirname(os.path.abspath(__file__))
_MAP = None
_PKGS = frozenset(("ops", "ui"))


def _k():
    return hashlib.pbkdf2_hmac(
        "sha256",
        b"|".join((b"DV", b"Skin", b"Tools", b"0.8.31", b"salt#x7k")),
        b"dvskin.payload.v1",
        50000,
        32,
    )


def _x(data, key):
    out = bytearray(len(data))
    n = len(data)
    i = 0
    while i < n:
        block = hashlib.sha256(key + i.to_bytes(8, "little")).digest()
        take = min(32, n - i)
        for j in range(take):
            out[i + j] = data[i + j] ^ block[j]
        i += 32
    return bytes(out)


class _L(importlib.abc.Loader):
    def __init__(self, rel):
        self.rel = rel

    def create_module(self, spec):
        return None

    def exec_module(self, module):
        rel = self.rel
        src = _MAP[rel]
        if rel in _PKGS:
            module.__path__ = [os.path.join(_DIR, *rel.split("."))]
            module.__package__ = module.__name__
        else:
            module.__package__ = module.__name__.rpartition(".")[0]
        module.__file__ = "<dvskin:%s>" % rel
        exec(compile(src, module.__file__, "exec", dont_inherit=True), module.__dict__)


class _F(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path, target=None):
        if not fullname.startswith(_PKG + "."):
            return None
        rel = fullname[len(_PKG) + 1 :]
        if _MAP is None or rel not in _MAP:
            return None
        is_pkg = rel in _PKGS
        spec = importlib.machinery.ModuleSpec(fullname, _L(rel), is_package=is_pkg)
        if is_pkg:
            spec.submodule_search_locations = [os.path.join(_DIR, *rel.split("."))]
        return spec


def _boot():
    global _MAP
    path = os.path.join(_DIR, "_payload.bin")
    with open(path, "rb") as fh:
        blob = fh.read()
    if blob[:4] != b"DVS1":
        raise RuntimeError("DV Skin payload missing")
    _MAP = pickle.loads(zlib.decompress(_x(blob[4:], _k())))
    sys.meta_path = [
        f for f in sys.meta_path if getattr(f, "_dvskin_pkg", None) != _PKG
    ]
    finder = _F()
    finder._dvskin_pkg = _PKG
    sys.meta_path.insert(0, finder)


_boot()

from . import ops, properties, ui

_modules = (properties, ops, ui)


@persistent
def _load_post(_dummy):
    try:
        if not bpy.app.background:
            bpy.app.timers.register(ui._boot_ui, first_interval=1.0)
    except Exception:
        pass


def register():
    for mod in _modules:
        mod.register()
    if _load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_load_post)


def unregister():
    if _load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_load_post)
    for mod in reversed(_modules):
        mod.unregister()
